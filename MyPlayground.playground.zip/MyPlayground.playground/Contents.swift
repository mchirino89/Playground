//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

extension UIView {

    static func activate(constraints: [NSLayoutConstraint]) {
        constraints.forEach { ($0.firstItem as? UIView)?.translatesAutoresizingMaskIntoConstraints = false }
        NSLayoutConstraint.activate(constraints)
    }

    func center(in view: UIView, offset: UIOffset = .zero) {
        UIView.activate(constraints: [
            centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: offset.horizontal),
            centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: offset.vertical)
        ])
    }
}

class ReactiveButton: UIControl {

    private lazy var iconImageView: UIImageView = {
        let icon = UIImageView(image: nil)
        icon.tintColor = .blue
        return icon
    }()

    private var animator = UIViewPropertyAnimator()
    private let normalColor = UIColor.blue
    private let highlightedColor = UIColor.black

    enum IconName: String {
        case add
        case minus
    }

    var iconImage: UIImage? {
        didSet {
            iconImage = iconImage?.withRenderingMode(.alwaysTemplate)
            iconImageView.image = iconImage
        }
    }
    var tappedAction: () -> Void = {}

    override init(frame: CGRect) {
        super.init(frame: frame)
        sharedInit()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        sharedInit()
    }

    private func sharedInit() {
        backgroundColor = .gray

        addTarget(self, action: #selector(touchDown), for: [.touchDown, .touchDragEnter])
        addTarget(self, action: #selector(touchUp), for: [.touchUpInside, .touchDragExit, .touchCancel])

        addSubview(iconImageView)
        iconImageView.center(in: self)
    }

    override var intrinsicContentSize: CGSize {
        let size = UIScreen.main.bounds
        return CGSize(width: size.width, height: size.height / 2)
    }

    @objc private func touchDown() {
        animator.stopAnimation(true)
        iconImageView.tintColor = highlightedColor
    }

    @objc private func touchUp() {
        animator = UIViewPropertyAnimator(duration: 0.5, curve: .easeOut, animations: {
            self.iconImageView.tintColor = self.normalColor
        })
        animator.startAnimation()
        tappedAction()
    }

}

class MyViewController : UIViewController {

    lazy var containerStackView: UIStackView = {
        let addButton = reactiveButton(with: .add)
        addButton.tappedAction = {
            print("Adding \(Date().timeIntervalSince1970)")
        }
        let minusButton = reactiveButton(with: .minus)
        minusButton.tappedAction = {
            print("Substracting \(Date().timeIntervalSince1970)")
        }
        let stack = UIStackView(arrangedSubviews: [addButton, minusButton])
        stack.distribution = .fillEqually
        stack.axis = .vertical
        stack.spacing = 2
        return stack
    }()

    override func loadView() {
        let view = UIView()
        view.backgroundColor = .black
        view.addSubview(containerStackView)
        containerStackView.center(in: view)
        self.view = view
    }

    func reactiveButton(with image: ReactiveButton.IconName) -> ReactiveButton {
        let button = ReactiveButton()
        button.iconImage = UIImage(named: image.rawValue)
        return button
    }
}

PlaygroundPage.current.liveView = MyViewController()
//PlaygroundPage.current.needsIndefiniteExecution = true
